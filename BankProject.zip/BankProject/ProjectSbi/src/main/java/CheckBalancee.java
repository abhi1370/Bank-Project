

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import conn.Conn;

/**
 * Servlet implementation class CheckBalancee
 */
@WebServlet("/CheckBalancee")
public class CheckBalancee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckBalancee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String code = request.getParameter("code");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (code == null || code.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>Account number is required.</h3>");
            return;
        }

        try (Connection con = Conn.getConn()) {
            PreparedStatement ps = con.prepareStatement("SELECT name, balance FROM account WHERE code = ?");
            ps.setString(1, code.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                double balance = rs.getDouble("balance");

                out.println("<div class='container mt-5'>");
                out.println("<h2>Account Balance Details</h2>");
                out.println("<p><strong>Account Number:</strong> " + code + "</p>");
                out.println("<p><strong>Account Holder:</strong> " + name + "</p>");
                out.println("<p><strong>Current Balance:</strong> ₹" + String.format("%.2f", balance) + "</p>");
                out.println("</div>");
            } else {
                out.println("<h3 style='color:red;'>Account not found.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        }
	}

}
