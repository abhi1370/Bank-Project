

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;

import conn.Conn;

/**
 * Servlet implementation class CreateAccountUser
 */
@WebServlet("/CreateAccountUser")
@MultipartConfig(
		fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
	    maxFileSize = 1024 * 1024 * 10,       // 10MB
	    maxRequestSize = 1024 * 1024 * 50     // 50MB
		)
public class CreateAccountUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String UPLOAD_DIR = "images";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        long min = 50000000000L;
        long max = 59999999999L;
        long randomNumber = min + (long)(Math.random() * (max - min));
        String Code = String.valueOf(randomNumber);  // Replaces user input


        String acc = request.getParameter("accounttype");
        String name = request.getParameter("name");
        String fname = request.getParameter("fathername");
        String mname = request.getParameter("mothername");
        String gender = request.getParameter("gender");
        String email = request.getParameter("Email");
        String phone = request.getParameter("Phone");
        String aadhar = request.getParameter("Aadhar");
        String State = request.getParameter("state");
        String address = request.getParameter("Address");
        String code = request.getParameter("code");
        String balance = request.getParameter("balance");


        Part part = request.getPart("photo");
        String originalFileName = extractFileName(part);
        String contentType = part.getContentType();
        

        // Allow only image files
        if (!contentType.startsWith("image/")) {
            response.getWriter().println("Error: Only image files are allowed.");
            return;
        }

        // Generate unique file name
        String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
        String newFileName = System.currentTimeMillis() + fileExtension;

        // Build upload path
        String applicationPath = getServletContext().getRealPath("");
        String uploadPath = applicationPath + File.separator + UPLOAD_DIR;

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        String fullSavePath = uploadPath + File.separator + newFileName;
        part.write(fullSavePath);  // Save file to disk

        String dbFilePath = UPLOAD_DIR + File.separator + newFileName;

        // Save metadata to DB
        try {
            Connection con = Conn.getConn();

            PreparedStatement pst = con.prepareStatement(
                "INSERT INTO account(code, accounttype, name, fathername, mothername,gender,Email,Phone,Aadhar,state,photo,Address,path,balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)"
            );
            pst.setString(1, Code);
            pst.setString(2, acc);
            pst.setString(3, name);
            pst.setString(4, fname);
            pst.setString(5, mname);
            pst.setString(6, gender);
            pst.setString(7, email);
            pst.setString(8, phone);
            pst.setString(9, aadhar);
            pst.setString(10, State);
            pst.setString(11, dbFilePath);
            pst.setString(13, fullSavePath);
            pst.setString(12, address);
            pst.setString(14, balance);

            pst.executeUpdate();
            con.close();
            
            response.sendRedirect("FinalSubmitUser.jsp?Code=" + URLEncoder.encode(Code, "UTF-8"));
        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Extract filename from HTTP header
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        for (String token : contentDisp.split(";")) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return "";
    }
}
