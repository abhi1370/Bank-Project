
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.*;

import conn.Conn;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/WithdrawAmount")
public class WithdrawAmount extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String code = request.getParameter("code");
        String name = "";

        if (code == null || code.trim().isEmpty()) {
            response.setContentType("text/plain");
            response.getWriter().write("");
            return;
        }

        try (Connection con = Conn.getConn()) {
            PreparedStatement ps = con.prepareStatement("SELECT name FROM account WHERE code = ?");
            ps.setString(1, code.trim());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.setContentType("text/plain");
        response.getWriter().write(name);
    }

    // 🟡 POST: Deposit amount, update balance, log transaction, simulate SMS
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String code = request.getParameter("code");
        String amountStr = request.getParameter("amount");

        if (code == null || code.trim().isEmpty() || amountStr == null || amountStr.trim().isEmpty()) {
            response.getWriter().println("Error: Code or amount is missing.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr.trim());

            try (Connection con = Conn.getConn()) {
                PreparedStatement ps = con.prepareStatement("SELECT balance, phone, name FROM account WHERE code = ?");
                ps.setString(1, code.trim());
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    double current = rs.getDouble("balance");
                    double updated = current - amount;
                    String phone = rs.getString("phone");
                    String name = rs.getString("name");
                    if (amount > current) {
                        response.getWriter().println("Insufficient balance");
                        return;
                    }

                    // Update balance
                    PreparedStatement update = con.prepareStatement("UPDATE account SET balance = ? WHERE code = ?");
                    update.setDouble(1, updated);
                    update.setString(2, code.trim());
                    update.executeUpdate();

                    // Log transaction
                    PreparedStatement log = con.prepareStatement(
                        "INSERT INTO transactions(code, amount, type) VALUES (?, ?, 'withdraw')");
                    log.setString(1, code.trim());
                    log.setDouble(2, amount);
                    log.executeUpdate();

                    System.out.println("SMS to " + phone + ": Dear " + name + ", ₹" + amount
                            + " Withdraw. New balance: ₹" + updated);

                    response.sendRedirect("Admin/WithdrawNotify.jsp?code=" + URLEncoder.encode(code.trim(), "UTF-8"));
                } else {
                    response.sendRedirect("deposit.jsp?msg=notfound");
                }
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("Error: Invalid amount format.");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}