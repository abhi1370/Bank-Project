

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;

import conn.Conn;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/UpdateAcc")
@MultipartConfig
public class UpdateAcc extends HttpServlet {
    private static final String UPLOAD_DIR = "images";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("code");
        String accounttype = request.getParameter("accounttype");
        String name = request.getParameter("name");
        String fathername = request.getParameter("fathername");
        String mothername = request.getParameter("mothername");
        String gender = request.getParameter("gender");
        String email = request.getParameter("Email");
        String phone = request.getParameter("Phone");
        String aadhar = request.getParameter("Aadhar");
        String state = request.getParameter("state");
        String address = request.getParameter("Address");
        String balance = request.getParameter("balance");
        String oldPhotoPath = request.getParameter("oldPhoto");

        String newPhotoPath = oldPhotoPath;

        Part part = request.getPart("photo");
        if (part != null && part.getSize() > 0 && part.getContentType().startsWith("image/")) {
            String appPath = getServletContext().getRealPath("");
            String uploadPath = appPath + File.separator + UPLOAD_DIR;

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            String fileName = System.currentTimeMillis() + "_" + part.getSubmittedFileName();
            String filePath = uploadPath + File.separator + fileName;
            part.write(filePath);

            newPhotoPath = UPLOAD_DIR + "/" + fileName;
        }

        try (Connection conn = Conn.getConn()) {
            String sql = "UPDATE account SET accounttype=?, name=?, fathername=?, mothername=?, gender=?, Email=?, Phone=?, Aadhar=?, state=?, Address=?, photo=?, balance=? WHERE code=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, accounttype);
            ps.setString(2, name);
            ps.setString(3, fathername);
            ps.setString(4, mothername);
            ps.setString(5, gender);
            ps.setString(6, email);
            ps.setString(7, phone);
            ps.setString(8, aadhar);
            ps.setString(9, state);
            ps.setString(10, address);
            ps.setString(11, newPhotoPath);
            ps.setString(12, balance);
            ps.setString(13, code);

            int updated = ps.executeUpdate();

            if (updated > 0) {
            	response.sendRedirect("FinalSubmit.jsp?Code=" + code);

            	} else {
                response.sendRedirect("UpdateAccount.jsp?code=" + code + "&msg=notfound");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("UpdateAccount.jsp?code=" + code + "&msg=error");
        }
    }
}