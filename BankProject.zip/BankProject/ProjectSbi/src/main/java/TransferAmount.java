
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.*;

import conn.Conn;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/TransferAmount")
public class TransferAmount extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String code = request.getParameter("code");
        String name = "";

        if (code == null || code.trim().isEmpty()) {
            response.setContentType("text/plain");
            response.getWriter().write("");
            return;
        }

        try (Connection con = Conn.getConn()) {
            PreparedStatement ps = con.prepareStatement("SELECT name FROM account WHERE code = ?");
            ps.setString(1, code.trim());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.setContentType("text/plain");
        response.getWriter().write(name);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String fromCode = request.getParameter("code");
        String toCode = request.getParameter("tocode");
        String amountStr = request.getParameter("amount");

        if (fromCode == null || toCode == null || amountStr == null ||
            fromCode.trim().isEmpty() || toCode.trim().isEmpty() || amountStr.trim().isEmpty()) {
            response.getWriter().println("Error: Missing input.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr.trim());

            if (amount <= 0) {
                response.getWriter().println("Error: Amount must be greater than zero.");
                return;
            }

            try (Connection con = Conn.getConn()) {
                // Auto-commit OFF for atomic transfer
                con.setAutoCommit(false);

                // Check sender
                PreparedStatement ps1 = con.prepareStatement("SELECT balance FROM account WHERE code = ?");
                ps1.setString(1, fromCode.trim());
                ResultSet rs1 = ps1.executeQuery();

                if (!rs1.next()) {
                    response.getWriter().println("Sender account not found.");
                    return;
                }

                double senderBalance = rs1.getDouble("balance");

                if (senderBalance < amount) {
                    response.getWriter().println("Insufficient funds.");
                    return;
                }

                // Check receiver
                PreparedStatement ps2 = con.prepareStatement("SELECT balance FROM account WHERE code = ?");
                ps2.setString(1, toCode.trim());
                ResultSet rs2 = ps2.executeQuery();

                if (!rs2.next()) {
                    response.getWriter().println("Receiver account not found.");
                    return;
                }

                PreparedStatement ps3 = con.prepareStatement("UPDATE account SET balance = balance - ? WHERE code = ?");
                ps3.setDouble(1, amount);
                ps3.setString(2, fromCode.trim());
                ps3.executeUpdate();

                PreparedStatement ps4 = con.prepareStatement("UPDATE account SET balance = balance + ? WHERE code = ?");
                ps4.setDouble(1, amount);
                ps4.setString(2, toCode.trim());
                ps4.executeUpdate();

                PreparedStatement ps5 = con.prepareStatement("INSERT INTO transactions(code, amount, type) VALUES (?, ?, 'transfer_out')");
                ps5.setString(1, fromCode.trim());
                ps5.setDouble(2, amount);
                ps5.executeUpdate();

                PreparedStatement ps6 = con.prepareStatement("INSERT INTO transactions(code, amount, type) VALUES (?, ?, 'transfer_in')");
                ps6.setString(1, toCode.trim());
                ps6.setDouble(2, amount);
                ps6.executeUpdate();

                con.commit();

                response.sendRedirect("Admin/Transfer.jsp?msgg=success");
            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().println("Error during transfer: " + e.getMessage());
            }

        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid amount.");
        }
    }
}